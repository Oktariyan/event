package data.retrofit

import data.response.EventDetailResponse
import data.response.EventResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("events")
    suspend fun getAllActiveEvent(
        @Query("active") active: Int = 1
    ): Response<EventResponse>

    @GET("events")
    suspend fun getAllFinishedEvent(
        @Query("active") active: Int = 0
    ): Response<EventResponse>

    @GET("events")
    suspend fun searchEvent(
        @Query("q") keyword: String,
        @Query("active") active: Int = -1
    ): Response<EventResponse>

    @GET("events/{id}")
    suspend fun getDetailEvent(
        @Path("id") id: Int
    ): Response<EventDetailResponse>
}
